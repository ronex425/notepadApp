package com.example.notepad.ui.nav
object Routes {
    const val SignIn = "signin"
    const val Notes = "notes"
    const val EditNote = "edit_note" // optional args: id
}